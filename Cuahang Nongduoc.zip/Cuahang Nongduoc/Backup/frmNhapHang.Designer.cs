﻿namespace CuahangNongduoc
{
    partial class frmNhapHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNhapHang));
            this.bindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolLuuThem = new System.Windows.Forms.ToolStripButton();
            this.toolChinhsua = new System.Windows.Forms.ToolStripButton();
            this.toolLuuThoat = new System.Windows.Forms.ToolStripButton();
            this.toolXoa = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolSavePrint = new System.Windows.Forms.ToolStripButton();
            this.toolXemLai = new System.Windows.Forms.ToolStripButton();
            this.toolThoat = new System.Windows.Forms.ToolStripButton();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.colMaPhieu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSanPham = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colMaSanPham = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDonGiaNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgayNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgaySanXuat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNgayHetHan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnThemSanPham = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.numThanhTien = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtNgayHetHan = new System.Windows.Forms.DateTimePicker();
            this.dtNgaySanXuat = new System.Windows.Forms.DateTimePicker();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.numGiaNhap = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.dtNgayNhap = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaSo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.grpThongtin = new System.Windows.Forms.GroupBox();
            this.cmbSanPham = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.numConNo = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.numDaTra = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbNhaCungCap = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.numTongTien = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.txtMaPhieu = new System.Windows.Forms.TextBox();
            this.btnThemNCC = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator)).BeginInit();
            this.bindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThanhTien)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaNhap)).BeginInit();
            this.grpThongtin.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numConNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDaTra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTongTien)).BeginInit();
            this.SuspendLayout();
            // 
            // bindingNavigator
            // 
            this.bindingNavigator.AddNewItem = null;
            this.bindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator.DeleteItem = null;
            this.bindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.toolLuuThem,
            this.toolChinhsua,
            this.toolLuuThoat,
            this.toolXoa,
            this.toolStripSeparator1,
            this.toolSavePrint,
            this.toolXemLai,
            this.toolThoat});
            this.bindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator.Name = "bindingNavigator";
            this.bindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator.Size = new System.Drawing.Size(731, 46);
            this.bindingNavigator.TabIndex = 0;
            this.bindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 43);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 43);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 43);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 46);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 46);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 43);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 43);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 46);
            // 
            // toolLuuThem
            // 
            this.toolLuuThem.Image = global::CuahangNongduoc.Properties.Resources.add;
            this.toolLuuThem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolLuuThem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolLuuThem.Name = "toolLuuThem";
            this.toolLuuThem.Size = new System.Drawing.Size(42, 43);
            this.toolLuuThem.Text = "Thêm";
            this.toolLuuThem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolLuuThem.Click += new System.EventHandler(this.toolLuuThem_Click);
            // 
            // toolChinhsua
            // 
            this.toolChinhsua.Image = global::CuahangNongduoc.Properties.Resources.edit;
            this.toolChinhsua.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolChinhsua.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolChinhsua.Name = "toolChinhsua";
            this.toolChinhsua.Size = new System.Drawing.Size(64, 43);
            this.toolChinhsua.Text = "Chỉnh sửa";
            this.toolChinhsua.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolChinhsua.Click += new System.EventHandler(this.toolChinhsua_Click);
            // 
            // toolLuuThoat
            // 
            this.toolLuuThoat.Image = global::CuahangNongduoc.Properties.Resources.save;
            this.toolLuuThoat.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolLuuThoat.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolLuuThoat.Name = "toolLuuThoat";
            this.toolLuuThoat.Size = new System.Drawing.Size(43, 43);
            this.toolLuuThoat.Text = "  Lưu  ";
            this.toolLuuThoat.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolLuuThoat.Click += new System.EventHandler(this.toolLuuThoat_Click);
            // 
            // toolXoa
            // 
            this.toolXoa.Image = global::CuahangNongduoc.Properties.Resources.remove;
            this.toolXoa.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolXoa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolXoa.Name = "toolXoa";
            this.toolXoa.Size = new System.Drawing.Size(43, 43);
            this.toolXoa.Text = "  Xóa  ";
            this.toolXoa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolXoa.Click += new System.EventHandler(this.toolXoa_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 46);
            // 
            // toolSavePrint
            // 
            this.toolSavePrint.Image = global::CuahangNongduoc.Properties.Resources.printer;
            this.toolSavePrint.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolSavePrint.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolSavePrint.Name = "toolSavePrint";
            this.toolSavePrint.Size = new System.Drawing.Size(55, 43);
            this.toolSavePrint.Text = "Trang in";
            this.toolSavePrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolSavePrint.Click += new System.EventHandler(this.toolSavePrint_Click);
            // 
            // toolXemLai
            // 
            this.toolXemLai.Image = global::CuahangNongduoc.Properties.Resources.reload_24;
            this.toolXemLai.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolXemLai.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolXemLai.Name = "toolXemLai";
            this.toolXemLai.Size = new System.Drawing.Size(50, 43);
            this.toolXemLai.Text = "Xem lại";
            this.toolXemLai.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolXemLai.Click += new System.EventHandler(this.frmNhapHang_Load);
            // 
            // toolThoat
            // 
            this.toolThoat.Image = global::CuahangNongduoc.Properties.Resources.stop;
            this.toolThoat.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolThoat.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolThoat.Name = "toolThoat";
            this.toolThoat.Size = new System.Drawing.Size(42, 43);
            this.toolThoat.Text = "Thoát";
            this.toolThoat.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolThoat.Click += new System.EventHandler(this.toolThoat_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Image = global::CuahangNongduoc.Properties.Resources.down;
            this.btnAdd.Location = new System.Drawing.Point(41, 148);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(47, 30);
            this.btnAdd.TabIndex = 15;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaPhieu,
            this.colSanPham,
            this.colMaSanPham,
            this.colDonGiaNhap,
            this.colSoLuong,
            this.colNgayNhap,
            this.colNgaySanXuat,
            this.colNgayHetHan});
            this.dataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView.Location = new System.Drawing.Point(0, 0);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.Size = new System.Drawing.Size(731, 238);
            this.dataGridView.TabIndex = 12;
            this.dataGridView.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dataGridView_UserDeletingRow);
            this.dataGridView.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dataGridView_DataError);
            // 
            // colMaPhieu
            // 
            this.colMaPhieu.DataPropertyName = "ID_PHIEU_NHAP";
            this.colMaPhieu.HeaderText = "Mã Phiếu";
            this.colMaPhieu.Name = "colMaPhieu";
            this.colMaPhieu.ReadOnly = true;
            // 
            // colSanPham
            // 
            this.colSanPham.DataPropertyName = "ID_SAN_PHAM";
            this.colSanPham.HeaderText = "Sản phẩm";
            this.colSanPham.Name = "colSanPham";
            this.colSanPham.ReadOnly = true;
            this.colSanPham.Width = 150;
            // 
            // colMaSanPham
            // 
            this.colMaSanPham.DataPropertyName = "ID";
            this.colMaSanPham.HeaderText = "Mã số";
            this.colMaSanPham.Name = "colMaSanPham";
            this.colMaSanPham.ReadOnly = true;
            // 
            // colDonGiaNhap
            // 
            this.colDonGiaNhap.DataPropertyName = "DON_GIA_NHAP";
            this.colDonGiaNhap.HeaderText = "Giá nhập";
            this.colDonGiaNhap.Name = "colDonGiaNhap";
            this.colDonGiaNhap.ReadOnly = true;
            // 
            // colSoLuong
            // 
            this.colSoLuong.DataPropertyName = "SO_LUONG";
            this.colSoLuong.HeaderText = "Số lượng";
            this.colSoLuong.Name = "colSoLuong";
            this.colSoLuong.ReadOnly = true;
            // 
            // colNgayNhap
            // 
            this.colNgayNhap.DataPropertyName = "NGAY_NHAP";
            this.colNgayNhap.HeaderText = "Ngày nhập";
            this.colNgayNhap.Name = "colNgayNhap";
            this.colNgayNhap.ReadOnly = true;
            // 
            // colNgaySanXuat
            // 
            this.colNgaySanXuat.DataPropertyName = "NGAY_SAN_XUAT";
            this.colNgaySanXuat.HeaderText = "Ngày sản xuất";
            this.colNgaySanXuat.Name = "colNgaySanXuat";
            this.colNgaySanXuat.ReadOnly = true;
            // 
            // colNgayHetHan
            // 
            this.colNgayHetHan.DataPropertyName = "NGAY_HET_HAN";
            this.colNgayHetHan.HeaderText = "Ngày hết hạn";
            this.colNgayHetHan.Name = "colNgayHetHan";
            this.colNgayHetHan.ReadOnly = true;
            // 
            // btnThemSanPham
            // 
            this.btnThemSanPham.Image = global::CuahangNongduoc.Properties.Resources.add_16;
            this.btnThemSanPham.Location = new System.Drawing.Point(227, 27);
            this.btnThemSanPham.Name = "btnThemSanPham";
            this.btnThemSanPham.Size = new System.Drawing.Size(24, 23);
            this.btnThemSanPham.TabIndex = 16;
            this.btnThemSanPham.UseVisualStyleBackColor = true;
            this.btnThemSanPham.Click += new System.EventHandler(this.btnThemSanPham_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Image = global::CuahangNongduoc.Properties.Resources.up;
            this.btnRemove.Location = new System.Drawing.Point(104, 148);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(48, 31);
            this.btnRemove.TabIndex = 14;
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // numThanhTien
            // 
            this.numThanhTien.BackColor = System.Drawing.Color.White;
            this.numThanhTien.Location = new System.Drawing.Point(313, 76);
            this.numThanhTien.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numThanhTien.Name = "numThanhTien";
            this.numThanhTien.ReadOnly = true;
            this.numThanhTien.Size = new System.Drawing.Size(81, 20);
            this.numThanhTien.TabIndex = 13;
            this.numThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numThanhTien.ThousandsSeparator = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(257, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Thành tiền";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dataGridView);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 230);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(731, 238);
            this.panel2.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Ngày hết hạn";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Ngày sản xuất";
            // 
            // dtNgayHetHan
            // 
            this.dtNgayHetHan.CustomFormat = "dd/MM/yyyy";
            this.dtNgayHetHan.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayHetHan.Location = new System.Drawing.Point(93, 106);
            this.dtNgayHetHan.Name = "dtNgayHetHan";
            this.dtNgayHetHan.Size = new System.Drawing.Size(158, 20);
            this.dtNgayHetHan.TabIndex = 9;
            // 
            // dtNgaySanXuat
            // 
            this.dtNgaySanXuat.CustomFormat = "dd/MM/yyyy";
            this.dtNgaySanXuat.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgaySanXuat.Location = new System.Drawing.Point(93, 80);
            this.dtNgaySanXuat.Name = "dtNgaySanXuat";
            this.dtNgaySanXuat.Size = new System.Drawing.Size(158, 20);
            this.dtNgaySanXuat.TabIndex = 8;
            // 
            // numSoLuong
            // 
            this.numSoLuong.Location = new System.Drawing.Point(313, 50);
            this.numSoLuong.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numSoLuong.Name = "numSoLuong";
            this.numSoLuong.Size = new System.Drawing.Size(81, 20);
            this.numSoLuong.TabIndex = 7;
            this.numSoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numSoLuong.ThousandsSeparator = true;
            this.numSoLuong.ValueChanged += new System.EventHandler(this.numGiaNhap_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(257, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Số lượng";
            // 
            // numGiaNhap
            // 
            this.numGiaNhap.Location = new System.Drawing.Point(313, 26);
            this.numGiaNhap.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numGiaNhap.Name = "numGiaNhap";
            this.numGiaNhap.Size = new System.Drawing.Size(81, 20);
            this.numGiaNhap.TabIndex = 5;
            this.numGiaNhap.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numGiaNhap.ThousandsSeparator = true;
            this.numGiaNhap.ValueChanged += new System.EventHandler(this.numGiaNhap_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(257, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Giá nhập";
            // 
            // dtNgayNhap
            // 
            this.dtNgayNhap.CustomFormat = "dd/MM/yyyy";
            this.dtNgayNhap.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayNhap.Location = new System.Drawing.Point(77, 78);
            this.dtNgayNhap.Name = "dtNgayNhap";
            this.dtNgayNhap.Size = new System.Drawing.Size(158, 20);
            this.dtNgayNhap.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Mã số";
            // 
            // txtMaSo
            // 
            this.txtMaSo.Location = new System.Drawing.Point(93, 54);
            this.txtMaSo.Name = "txtMaSo";
            this.txtMaSo.Size = new System.Drawing.Size(158, 20);
            this.txtMaSo.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sản phẩm";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Ngày nhập";
            // 
            // grpThongtin
            // 
            this.grpThongtin.Controls.Add(this.btnThemSanPham);
            this.grpThongtin.Controls.Add(this.btnAdd);
            this.grpThongtin.Controls.Add(this.btnRemove);
            this.grpThongtin.Controls.Add(this.numThanhTien);
            this.grpThongtin.Controls.Add(this.label9);
            this.grpThongtin.Controls.Add(this.label6);
            this.grpThongtin.Controls.Add(this.label5);
            this.grpThongtin.Controls.Add(this.dtNgayHetHan);
            this.grpThongtin.Controls.Add(this.dtNgaySanXuat);
            this.grpThongtin.Controls.Add(this.numSoLuong);
            this.grpThongtin.Controls.Add(this.label4);
            this.grpThongtin.Controls.Add(this.numGiaNhap);
            this.grpThongtin.Controls.Add(this.label3);
            this.grpThongtin.Controls.Add(this.label2);
            this.grpThongtin.Controls.Add(this.txtMaSo);
            this.grpThongtin.Controls.Add(this.label1);
            this.grpThongtin.Controls.Add(this.cmbSanPham);
            this.grpThongtin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpThongtin.Location = new System.Drawing.Point(239, 0);
            this.grpThongtin.Name = "grpThongtin";
            this.grpThongtin.Size = new System.Drawing.Size(492, 184);
            this.grpThongtin.TabIndex = 12;
            this.grpThongtin.TabStop = false;
            this.grpThongtin.Text = "Thông tin";
            // 
            // cmbSanPham
            // 
            this.cmbSanPham.FormattingEnabled = true;
            this.cmbSanPham.Location = new System.Drawing.Point(93, 29);
            this.cmbSanPham.Name = "cmbSanPham";
            this.cmbSanPham.Size = new System.Drawing.Size(128, 21);
            this.cmbSanPham.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.grpThongtin);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(731, 184);
            this.panel1.TabIndex = 18;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnThemNCC);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.numConNo);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.numDaTra);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.cmbNhaCungCap);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.numTongTien);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.dtNgayNhap);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txtMaPhieu);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(239, 184);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 162);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 13);
            this.label13.TabIndex = 31;
            this.label13.Text = "Còn nợ";
            // 
            // numConNo
            // 
            this.numConNo.Location = new System.Drawing.Point(76, 160);
            this.numConNo.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numConNo.Name = "numConNo";
            this.numConNo.Size = new System.Drawing.Size(157, 20);
            this.numConNo.TabIndex = 30;
            this.numConNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numConNo.ThousandsSeparator = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 136);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 29;
            this.label12.Text = "Đã trả";
            // 
            // numDaTra
            // 
            this.numDaTra.Location = new System.Drawing.Point(76, 134);
            this.numDaTra.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numDaTra.Name = "numDaTra";
            this.numDaTra.Size = new System.Drawing.Size(157, 20);
            this.numDaTra.TabIndex = 28;
            this.numDaTra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numDaTra.ThousandsSeparator = true;
            this.numDaTra.ValueChanged += new System.EventHandler(this.numDaTra_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 54);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 27;
            this.label11.Text = "Nhà CC";
            // 
            // cmbNhaCungCap
            // 
            this.cmbNhaCungCap.FormattingEnabled = true;
            this.cmbNhaCungCap.Location = new System.Drawing.Point(78, 51);
            this.cmbNhaCungCap.Name = "cmbNhaCungCap";
            this.cmbNhaCungCap.Size = new System.Drawing.Size(137, 21);
            this.cmbNhaCungCap.TabIndex = 26;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 110);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Tổng tiền";
            // 
            // numTongTien
            // 
            this.numTongTien.Location = new System.Drawing.Point(77, 107);
            this.numTongTien.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.numTongTien.Name = "numTongTien";
            this.numTongTien.Size = new System.Drawing.Size(157, 20);
            this.numTongTien.TabIndex = 24;
            this.numTongTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numTongTien.ThousandsSeparator = true;
            this.numTongTien.ValueChanged += new System.EventHandler(this.numDaTra_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "Mã phiếu";
            // 
            // txtMaPhieu
            // 
            this.txtMaPhieu.Location = new System.Drawing.Point(78, 25);
            this.txtMaPhieu.Name = "txtMaPhieu";
            this.txtMaPhieu.Size = new System.Drawing.Size(155, 20);
            this.txtMaPhieu.TabIndex = 22;
            // 
            // btnThemNCC
            // 
            this.btnThemNCC.Image = global::CuahangNongduoc.Properties.Resources.add_16;
            this.btnThemNCC.Location = new System.Drawing.Point(213, 50);
            this.btnThemNCC.Name = "btnThemNCC";
            this.btnThemNCC.Size = new System.Drawing.Size(24, 23);
            this.btnThemNCC.TabIndex = 32;
            this.btnThemNCC.UseVisualStyleBackColor = true;
            this.btnThemNCC.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmNhapHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 468);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.bindingNavigator);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmNhapHang";
            this.Text = "NHAP HANG";
            this.Load += new System.EventHandler(this.frmNhapHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator)).EndInit();
            this.bindingNavigator.ResumeLayout(false);
            this.bindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numThanhTien)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaNhap)).EndInit();
            this.grpThongtin.ResumeLayout(false);
            this.grpThongtin.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numConNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDaTra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTongTien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingNavigator bindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Button btnThemSanPham;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.NumericUpDown numThanhTien;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtNgayHetHan;
        private System.Windows.Forms.DateTimePicker dtNgaySanXuat;
        private System.Windows.Forms.NumericUpDown numSoLuong;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numGiaNhap;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtNgayNhap;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMaSo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox grpThongtin;
        private System.Windows.Forms.ComboBox cmbSanPham;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numTongTien;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtMaPhieu;
        private System.Windows.Forms.ToolStripButton toolLuuThem;
        private System.Windows.Forms.ToolStripButton toolLuuThoat;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolThoat;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaPhieu;
        private System.Windows.Forms.DataGridViewComboBoxColumn colSanPham;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaSanPham;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGiaNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNgayNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNgaySanXuat;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNgayHetHan;
        private System.Windows.Forms.ToolStripButton toolXemLai;
        private System.Windows.Forms.ToolStripButton toolSavePrint;
        private System.Windows.Forms.ToolStripButton toolChinhsua;
        private System.Windows.Forms.ToolStripButton toolXoa;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown numConNo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numDaTra;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbNhaCungCap;
        private System.Windows.Forms.Button btnThemNCC;


    }
}