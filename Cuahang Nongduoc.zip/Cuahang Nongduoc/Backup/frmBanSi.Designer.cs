﻿namespace CuahangNongduoc
{
    partial class frmBanSi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBanSi));
            this.bindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolThem = new System.Windows.Forms.ToolStripButton();
            this.toolChinhSua = new System.Windows.Forms.ToolStripButton();
            this.toolLuu = new System.Windows.Forms.ToolStripButton();
            this.toolXoa = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolIn = new System.Windows.Forms.ToolStripButton();
            this.toolXemLai = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolThoat = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvDanhsachSP = new System.Windows.Forms.DataGridView();
            this.colMaPhieuBan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMaSanPham = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colDonGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colThanhTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtGiaBQGQ = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtGiaBanLe = new System.Windows.Forms.TextBox();
            this.txtGiaBanSi = new System.Windows.Forms.TextBox();
            this.txtGiaNhap = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.numThanhTien = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.numDonGia = new System.Windows.Forms.NumericUpDown();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbMaSanPham = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbSanPham = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.grpPhieuBanLe = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaPhieu = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtNgayLapPhieu = new System.Windows.Forms.DateTimePicker();
            this.cmbKhachHang = new System.Windows.Forms.ComboBox();
            this.numConNo = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numTongTien = new System.Windows.Forms.NumericUpDown();
            this.numDaTra = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnThemDaiLy = new System.Windows.Forms.Button();
            this.btnThemSanPham = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator)).BeginInit();
            this.bindingNavigator.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhsachSP)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThanhTien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDonGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            this.grpPhieuBanLe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numConNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTongTien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDaTra)).BeginInit();
            this.SuspendLayout();
            // 
            // bindingNavigator
            // 
            this.bindingNavigator.AddNewItem = null;
            this.bindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator.DeleteItem = null;
            this.bindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.toolThem,
            this.toolChinhSua,
            this.toolLuu,
            this.toolXoa,
            this.toolStripSeparator2,
            this.toolIn,
            this.toolXemLai,
            this.toolStripSeparator1,
            this.toolThoat});
            this.bindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator.Name = "bindingNavigator";
            this.bindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator.Size = new System.Drawing.Size(750, 46);
            this.bindingNavigator.TabIndex = 0;
            this.bindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 43);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 43);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 43);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 46);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 46);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 43);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 43);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 46);
            // 
            // toolThem
            // 
            this.toolThem.Image = global::CuahangNongduoc.Properties.Resources.add;
            this.toolThem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolThem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolThem.Name = "toolThem";
            this.toolThem.Size = new System.Drawing.Size(42, 43);
            this.toolThem.Text = "Thêm";
            this.toolThem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolThem.Click += new System.EventHandler(this.toolLuu_Them_Click);
            // 
            // toolChinhSua
            // 
            this.toolChinhSua.Image = global::CuahangNongduoc.Properties.Resources.edit;
            this.toolChinhSua.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolChinhSua.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolChinhSua.Name = "toolChinhSua";
            this.toolChinhSua.Size = new System.Drawing.Size(64, 43);
            this.toolChinhSua.Text = "Chỉnh sửa";
            this.toolChinhSua.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolChinhSua.Click += new System.EventHandler(this.toolChinhSua_Click);
            // 
            // toolLuu
            // 
            this.toolLuu.Image = global::CuahangNongduoc.Properties.Resources.save;
            this.toolLuu.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolLuu.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolLuu.Name = "toolLuu";
            this.toolLuu.Size = new System.Drawing.Size(43, 43);
            this.toolLuu.Text = "  Lưu  ";
            this.toolLuu.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolLuu.Click += new System.EventHandler(this.toolLuu_Click);
            // 
            // toolXoa
            // 
            this.toolXoa.Image = global::CuahangNongduoc.Properties.Resources.remove;
            this.toolXoa.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolXoa.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolXoa.Name = "toolXoa";
            this.toolXoa.Size = new System.Drawing.Size(43, 43);
            this.toolXoa.Text = "  Xóa  ";
            this.toolXoa.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolXoa.Click += new System.EventHandler(this.toolXoa_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 46);
            // 
            // toolIn
            // 
            this.toolIn.Image = global::CuahangNongduoc.Properties.Resources.printer;
            this.toolIn.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolIn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolIn.Name = "toolIn";
            this.toolIn.Size = new System.Drawing.Size(55, 43);
            this.toolIn.Text = "Trang in";
            this.toolIn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolIn.Click += new System.EventHandler(this.toolLuuIn_Click);
            // 
            // toolXemLai
            // 
            this.toolXemLai.Image = global::CuahangNongduoc.Properties.Resources.reload_24;
            this.toolXemLai.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolXemLai.Name = "toolXemLai";
            this.toolXemLai.RightToLeftAutoMirrorImage = true;
            this.toolXemLai.Size = new System.Drawing.Size(50, 43);
            this.toolXemLai.Text = "Xem lại";
            this.toolXemLai.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolXemLai.Click += new System.EventHandler(this.toolXemLai_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 46);
            // 
            // toolThoat
            // 
            this.toolThoat.Image = global::CuahangNongduoc.Properties.Resources.stop;
            this.toolThoat.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolThoat.Name = "toolThoat";
            this.toolThoat.RightToLeftAutoMirrorImage = true;
            this.toolThoat.Size = new System.Drawing.Size(42, 43);
            this.toolThoat.Text = "Thoát";
            this.toolThoat.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolThoat.Click += new System.EventHandler(this.toolThoat_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox1.Location = new System.Drawing.Point(0, 240);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(750, 145);
            this.groupBox1.TabIndex = 60;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Danh sách Sản phẩm";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dgvDanhsachSP);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(744, 126);
            this.panel2.TabIndex = 1;
            // 
            // dgvDanhsachSP
            // 
            this.dgvDanhsachSP.AllowUserToAddRows = false;
            this.dgvDanhsachSP.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvDanhsachSP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhsachSP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colMaPhieuBan,
            this.colMaSanPham,
            this.colDonGia,
            this.colSoLuong,
            this.colThanhTien});
            this.dgvDanhsachSP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDanhsachSP.Location = new System.Drawing.Point(0, 0);
            this.dgvDanhsachSP.Name = "dgvDanhsachSP";
            this.dgvDanhsachSP.ReadOnly = true;
            this.dgvDanhsachSP.Size = new System.Drawing.Size(744, 126);
            this.dgvDanhsachSP.TabIndex = 6;
            this.dgvDanhsachSP.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dgvDanhsachSP_UserDeletingRow);
            this.dgvDanhsachSP.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvDanhsachSP_DataError);
            // 
            // colMaPhieuBan
            // 
            this.colMaPhieuBan.DataPropertyName = "ID_PHIEU_BAN";
            this.colMaPhieuBan.HeaderText = "MaPhieuBan";
            this.colMaPhieuBan.Name = "colMaPhieuBan";
            this.colMaPhieuBan.ReadOnly = true;
            this.colMaPhieuBan.Visible = false;
            // 
            // colMaSanPham
            // 
            this.colMaSanPham.DataPropertyName = "ID_MA_SAN_PHAM";
            this.colMaSanPham.HeaderText = "Mã số";
            this.colMaSanPham.Name = "colMaSanPham";
            this.colMaSanPham.ReadOnly = true;
            this.colMaSanPham.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.colMaSanPham.Width = 150;
            // 
            // colDonGia
            // 
            this.colDonGia.DataPropertyName = "DON_GIA";
            this.colDonGia.HeaderText = "Đơn giá";
            this.colDonGia.Name = "colDonGia";
            this.colDonGia.ReadOnly = true;
            // 
            // colSoLuong
            // 
            this.colSoLuong.DataPropertyName = "SO_LUONG";
            this.colSoLuong.HeaderText = "Số lượng";
            this.colSoLuong.Name = "colSoLuong";
            this.colSoLuong.ReadOnly = true;
            // 
            // colThanhTien
            // 
            this.colThanhTien.DataPropertyName = "THANH_TIEN";
            this.colThanhTien.HeaderText = "Thành tiền";
            this.colThanhTien.Name = "colThanhTien";
            this.colThanhTien.ReadOnly = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.grpPhieuBanLe);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(750, 188);
            this.panel1.TabIndex = 61;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnThemSanPham);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.btnAdd);
            this.groupBox2.Controls.Add(this.btnRemove);
            this.groupBox2.Controls.Add(this.numThanhTien);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.numDonGia);
            this.groupBox2.Controls.Add(this.numSoLuong);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.cmbMaSanPham);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.cmbSanPham);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(242, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(508, 188);
            this.groupBox2.TabIndex = 61;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chọn sản phẩm";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtGiaBQGQ);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.txtGiaBanLe);
            this.groupBox3.Controls.Add(this.txtGiaBanSi);
            this.groupBox3.Controls.Add(this.txtGiaNhap);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Location = new System.Drawing.Point(242, 16);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(191, 128);
            this.groupBox3.TabIndex = 61;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Thông tin sản phẩm";
            // 
            // txtGiaBQGQ
            // 
            this.txtGiaBQGQ.BackColor = System.Drawing.Color.White;
            this.txtGiaBQGQ.Location = new System.Drawing.Point(75, 103);
            this.txtGiaBQGQ.Name = "txtGiaBQGQ";
            this.txtGiaBQGQ.ReadOnly = true;
            this.txtGiaBQGQ.Size = new System.Drawing.Size(109, 20);
            this.txtGiaBQGQ.TabIndex = 60;
            this.txtGiaBQGQ.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 106);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 59;
            this.label15.Text = "Giá BQGQ";
            // 
            // txtGiaBanLe
            // 
            this.txtGiaBanLe.BackColor = System.Drawing.Color.White;
            this.txtGiaBanLe.Location = new System.Drawing.Point(75, 77);
            this.txtGiaBanLe.Name = "txtGiaBanLe";
            this.txtGiaBanLe.ReadOnly = true;
            this.txtGiaBanLe.Size = new System.Drawing.Size(109, 20);
            this.txtGiaBanLe.TabIndex = 58;
            this.txtGiaBanLe.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtGiaBanSi
            // 
            this.txtGiaBanSi.BackColor = System.Drawing.Color.White;
            this.txtGiaBanSi.Location = new System.Drawing.Point(75, 49);
            this.txtGiaBanSi.Name = "txtGiaBanSi";
            this.txtGiaBanSi.ReadOnly = true;
            this.txtGiaBanSi.Size = new System.Drawing.Size(109, 20);
            this.txtGiaBanSi.TabIndex = 57;
            this.txtGiaBanSi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtGiaNhap
            // 
            this.txtGiaNhap.BackColor = System.Drawing.Color.White;
            this.txtGiaNhap.Location = new System.Drawing.Point(75, 24);
            this.txtGiaNhap.Name = "txtGiaNhap";
            this.txtGiaNhap.ReadOnly = true;
            this.txtGiaNhap.Size = new System.Drawing.Size(109, 20);
            this.txtGiaNhap.TabIndex = 56;
            this.txtGiaNhap.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 80);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 13);
            this.label14.TabIndex = 55;
            this.label14.Text = "Giá bán lẽ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 53);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 13);
            this.label13.TabIndex = 54;
            this.label13.Text = "Giá bán sỉ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 13);
            this.label12.TabIndex = 53;
            this.label12.Text = "Giá nhập:";
            // 
            // btnAdd
            // 
            this.btnAdd.Image = global::CuahangNongduoc.Properties.Resources.down;
            this.btnAdd.Location = new System.Drawing.Point(69, 151);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(47, 30);
            this.btnAdd.TabIndex = 60;
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Image = global::CuahangNongduoc.Properties.Resources.up;
            this.btnRemove.Location = new System.Drawing.Point(122, 150);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(48, 31);
            this.btnRemove.TabIndex = 59;
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // numThanhTien
            // 
            this.numThanhTien.Location = new System.Drawing.Point(70, 124);
            this.numThanhTien.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.numThanhTien.Minimum = new decimal(new int[] {
            1000000000,
            0,
            0,
            -2147483648});
            this.numThanhTien.Name = "numThanhTien";
            this.numThanhTien.Size = new System.Drawing.Size(160, 20);
            this.numThanhTien.TabIndex = 58;
            this.numThanhTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numThanhTien.ThousandsSeparator = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 13);
            this.label7.TabIndex = 57;
            this.label7.Text = "Thành tiền";
            // 
            // numDonGia
            // 
            this.numDonGia.Location = new System.Drawing.Point(70, 72);
            this.numDonGia.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.numDonGia.Minimum = new decimal(new int[] {
            1000000000,
            0,
            0,
            -2147483648});
            this.numDonGia.Name = "numDonGia";
            this.numDonGia.Size = new System.Drawing.Size(160, 20);
            this.numDonGia.TabIndex = 54;
            this.numDonGia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numDonGia.ThousandsSeparator = true;
            this.numDonGia.ValueChanged += new System.EventHandler(this.numDonGia_ValueChanged);
            // 
            // numSoLuong
            // 
            this.numSoLuong.Location = new System.Drawing.Point(70, 98);
            this.numSoLuong.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.numSoLuong.Minimum = new decimal(new int[] {
            1000000000,
            0,
            0,
            -2147483648});
            this.numSoLuong.Name = "numSoLuong";
            this.numSoLuong.Size = new System.Drawing.Size(160, 20);
            this.numSoLuong.TabIndex = 56;
            this.numSoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numSoLuong.ThousandsSeparator = true;
            this.numSoLuong.ValueChanged += new System.EventHandler(this.numDonGia_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 98);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 55;
            this.label9.Text = "Số lượng";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 72);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 53;
            this.label11.Text = "Đơn giá";
            // 
            // cmbMaSanPham
            // 
            this.cmbMaSanPham.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbMaSanPham.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMaSanPham.FormattingEnabled = true;
            this.cmbMaSanPham.Location = new System.Drawing.Point(70, 45);
            this.cmbMaSanPham.Name = "cmbMaSanPham";
            this.cmbMaSanPham.Size = new System.Drawing.Size(160, 21);
            this.cmbMaSanPham.TabIndex = 51;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 52;
            this.label4.Text = "Mã số";
            // 
            // cmbSanPham
            // 
            this.cmbSanPham.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbSanPham.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSanPham.FormattingEnabled = true;
            this.cmbSanPham.Location = new System.Drawing.Point(70, 19);
            this.cmbSanPham.Name = "cmbSanPham";
            this.cmbSanPham.Size = new System.Drawing.Size(135, 21);
            this.cmbSanPham.TabIndex = 49;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "Sản phẩm";
            // 
            // grpPhieuBanLe
            // 
            this.grpPhieuBanLe.Controls.Add(this.btnThemDaiLy);
            this.grpPhieuBanLe.Controls.Add(this.label2);
            this.grpPhieuBanLe.Controls.Add(this.txtMaPhieu);
            this.grpPhieuBanLe.Controls.Add(this.label1);
            this.grpPhieuBanLe.Controls.Add(this.dtNgayLapPhieu);
            this.grpPhieuBanLe.Controls.Add(this.cmbKhachHang);
            this.grpPhieuBanLe.Controls.Add(this.numConNo);
            this.grpPhieuBanLe.Controls.Add(this.label10);
            this.grpPhieuBanLe.Controls.Add(this.label5);
            this.grpPhieuBanLe.Controls.Add(this.numTongTien);
            this.grpPhieuBanLe.Controls.Add(this.numDaTra);
            this.grpPhieuBanLe.Controls.Add(this.label6);
            this.grpPhieuBanLe.Controls.Add(this.label8);
            this.grpPhieuBanLe.Dock = System.Windows.Forms.DockStyle.Left;
            this.grpPhieuBanLe.Location = new System.Drawing.Point(0, 0);
            this.grpPhieuBanLe.Name = "grpPhieuBanLe";
            this.grpPhieuBanLe.Size = new System.Drawing.Size(242, 188);
            this.grpPhieuBanLe.TabIndex = 60;
            this.grpPhieuBanLe.TabStop = false;
            this.grpPhieuBanLe.Text = "Phiếu bán lẽ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 56;
            this.label2.Text = "Mã Phiếu";
            // 
            // txtMaPhieu
            // 
            this.txtMaPhieu.Location = new System.Drawing.Point(82, 16);
            this.txtMaPhieu.Name = "txtMaPhieu";
            this.txtMaPhieu.Size = new System.Drawing.Size(154, 20);
            this.txtMaPhieu.TabIndex = 55;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 54;
            this.label1.Text = "Ngày lập";
            // 
            // dtNgayLapPhieu
            // 
            this.dtNgayLapPhieu.CustomFormat = "dd/MM/yyyy";
            this.dtNgayLapPhieu.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtNgayLapPhieu.Location = new System.Drawing.Point(82, 42);
            this.dtNgayLapPhieu.Name = "dtNgayLapPhieu";
            this.dtNgayLapPhieu.Size = new System.Drawing.Size(154, 20);
            this.dtNgayLapPhieu.TabIndex = 39;
            // 
            // cmbKhachHang
            // 
            this.cmbKhachHang.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbKhachHang.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbKhachHang.FormattingEnabled = true;
            this.cmbKhachHang.Location = new System.Drawing.Point(82, 68);
            this.cmbKhachHang.Name = "cmbKhachHang";
            this.cmbKhachHang.Size = new System.Drawing.Size(128, 21);
            this.cmbKhachHang.TabIndex = 46;
            // 
            // numConNo
            // 
            this.numConNo.Location = new System.Drawing.Point(82, 147);
            this.numConNo.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.numConNo.Minimum = new decimal(new int[] {
            1000000000,
            0,
            0,
            -2147483648});
            this.numConNo.Name = "numConNo";
            this.numConNo.Size = new System.Drawing.Size(154, 20);
            this.numConNo.TabIndex = 52;
            this.numConNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numConNo.ThousandsSeparator = true;
            this.numConNo.ValueChanged += new System.EventHandler(this.numTongTien_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 148);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 51;
            this.label10.Text = "Còn nợ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 48;
            this.label5.Text = "Đại lý";
            // 
            // numTongTien
            // 
            this.numTongTien.Location = new System.Drawing.Point(82, 95);
            this.numTongTien.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.numTongTien.Minimum = new decimal(new int[] {
            1000000000,
            0,
            0,
            -2147483648});
            this.numTongTien.Name = "numTongTien";
            this.numTongTien.Size = new System.Drawing.Size(154, 20);
            this.numTongTien.TabIndex = 45;
            this.numTongTien.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numTongTien.ThousandsSeparator = true;
            this.numTongTien.ValueChanged += new System.EventHandler(this.numTongTien_ValueChanged);
            // 
            // numDaTra
            // 
            this.numDaTra.Location = new System.Drawing.Point(82, 121);
            this.numDaTra.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.numDaTra.Minimum = new decimal(new int[] {
            1000000000,
            0,
            0,
            -2147483648});
            this.numDaTra.Name = "numDaTra";
            this.numDaTra.Size = new System.Drawing.Size(154, 20);
            this.numDaTra.TabIndex = 50;
            this.numDaTra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numDaTra.ThousandsSeparator = true;
            this.numDaTra.ValueChanged += new System.EventHandler(this.numTongTien_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 49;
            this.label6.Text = "Đã trả";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 96);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 42;
            this.label8.Text = "Tổng tiền";
            // 
            // btnThemDaiLy
            // 
            this.btnThemDaiLy.Image = global::CuahangNongduoc.Properties.Resources.add_16;
            this.btnThemDaiLy.Location = new System.Drawing.Point(212, 66);
            this.btnThemDaiLy.Name = "btnThemDaiLy";
            this.btnThemDaiLy.Size = new System.Drawing.Size(24, 24);
            this.btnThemDaiLy.TabIndex = 58;
            this.btnThemDaiLy.UseVisualStyleBackColor = true;
            this.btnThemDaiLy.Click += new System.EventHandler(this.btnThemDaiLy_Click);
            // 
            // btnThemSanPham
            // 
            this.btnThemSanPham.Image = global::CuahangNongduoc.Properties.Resources.add_16;
            this.btnThemSanPham.Location = new System.Drawing.Point(206, 17);
            this.btnThemSanPham.Name = "btnThemSanPham";
            this.btnThemSanPham.Size = new System.Drawing.Size(24, 24);
            this.btnThemSanPham.TabIndex = 63;
            this.btnThemSanPham.UseVisualStyleBackColor = true;
            this.btnThemSanPham.Click += new System.EventHandler(this.btnThemSanPham_Click);
            // 
            // frmBanSi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 385);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bindingNavigator);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmBanSi";
            this.Text = "BAN SI";
            this.Load += new System.EventHandler(this.frmNhapHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator)).EndInit();
            this.bindingNavigator.ResumeLayout(false);
            this.bindingNavigator.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhsachSP)).EndInit();
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThanhTien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDonGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            this.grpPhieuBanLe.ResumeLayout(false);
            this.grpPhieuBanLe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numConNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTongTien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDaTra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingNavigator bindingNavigator;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton toolThoat;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripButton toolLuu;
        private System.Windows.Forms.ToolStripButton toolThem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgvDanhsachSP;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox grpPhieuBanLe;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMaPhieu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtNgayLapPhieu;
        private System.Windows.Forms.ComboBox cmbKhachHang;
        private System.Windows.Forms.NumericUpDown numConNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numTongTien;
        private System.Windows.Forms.NumericUpDown numDaTra;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbMaSanPham;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbSanPham;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numThanhTien;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numDonGia;
        private System.Windows.Forms.NumericUpDown numSoLuong;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMaPhieuBan;
        private System.Windows.Forms.DataGridViewComboBoxColumn colMaSanPham;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDonGia;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn colThanhTien;
        private System.Windows.Forms.ToolStripButton toolIn;
        private System.Windows.Forms.ToolStripButton toolChinhSua;
        private System.Windows.Forms.ToolStripButton toolXemLai;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolXoa;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtGiaBQGQ;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtGiaBanLe;
        private System.Windows.Forms.TextBox txtGiaBanSi;
        private System.Windows.Forms.TextBox txtGiaNhap;
        private System.Windows.Forms.Button btnThemSanPham;
        private System.Windows.Forms.Button btnThemDaiLy;



    }
}